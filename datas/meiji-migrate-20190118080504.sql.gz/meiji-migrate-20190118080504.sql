# WordPress MySQL database migration
#
# Generated: Friday 18. January 2019 08:05 UTC
# Hostname: localhost
# Database: `meiji`
# URL: //meiji.local:8080
# Path: C:\\Projects\\KENNY\\meiji
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, nav_menu_item, page, post, sa_slider, wpocup_slider
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-01-08 06:31:30', '2019-01-08 06:31:30', 'Hi, this is a comment.\r\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\r\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=264 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://meiji.local:8080', 'yes'),
(2, 'home', 'http://meiji.local:8080', 'yes'),
(3, 'blogname', 'Meiji', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'blackant150@yahoo.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:108:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:37:"sa_slider/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"sa_slider/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"sa_slider/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"sa_slider/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"sa_slider/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"sa_slider/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"sa_slider/([^/]+)/embed/?$";s:57:"index.php?post_type=sa_slider&name=$matches[1]&embed=true";s:30:"sa_slider/([^/]+)/trackback/?$";s:51:"index.php?post_type=sa_slider&name=$matches[1]&tb=1";s:38:"sa_slider/([^/]+)/page/?([0-9]{1,})/?$";s:64:"index.php?post_type=sa_slider&name=$matches[1]&paged=$matches[2]";s:45:"sa_slider/([^/]+)/comment-page-([0-9]{1,})/?$";s:64:"index.php?post_type=sa_slider&name=$matches[1]&cpage=$matches[2]";s:34:"sa_slider/([^/]+)(?:/([0-9]+))?/?$";s:63:"index.php?post_type=sa_slider&name=$matches[1]&page=$matches[2]";s:26:"sa_slider/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"sa_slider/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"sa_slider/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"sa_slider/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"sa_slider/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"sa_slider/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=7&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:33:"slide-anything/slide-anything.php";i:1;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'wprig-master/dev', 'yes'),
(41, 'stylesheet', 'wprig-master/dev', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '43764', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '7', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '43764', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'nonce_key', 'rL$EPbp%rK3*7Hf:)TPn({wyxvSxXXJZL((AK80UVY.E8TA_0cG]X$X7sZX.OqH>', 'no'),
(109, 'nonce_salt', ']eC::/E4AF?Cawem:T:cX9p%)G>GNuctAD{&[NVi@WMY!W+6}O%P~]=OS*mq:wzw', 'no'),
(110, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'cron', 'a:6:{i:1547800290;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1547805801;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"f953bd603d96036fad62a863c8deaa45";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:70;}}}}i:1547836290;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1547879526;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1547880119;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(114, 'theme_mods_twentynineteen', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1546931250;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(122, 'auth_key', '@#9>EUFX?F_:k {./2}y8keO$q20=?Kgw6u3zoPdH/MAT~TK.y(a8`xYlC)+dKD{', 'no'),
(123, 'auth_salt', '^Fr8yTr-!zl247)FbHHX[aO+v1c(.zy/Y}?R{2|}q&Zgdj11IQf/IUPl+E2iCJ]]', 'no'),
(124, 'logged_in_key', 'aUGRg6kB*FXE{$:q*!7`gm>nAJZCH>q>41J;u]_*>Z:=c;JLTI1>E|?3zhC2DcrV', 'no'),
(125, 'logged_in_salt', '?mBLC@D3;u]$n@,b3fI9Am8}Y(PUYeA+LAH5vEvu#>fXzX<NOm|:7p?NpLM$;Vx ', 'no'),
(128, 'can_compress_scripts', '1', 'no'),
(142, 'current_theme', 'wprig', 'yes'),
(143, 'theme_mods_wprig-master/dev', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:36;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1546930459;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(144, 'theme_switched', '', 'yes'),
(204, 'wpocup_options', 'a:2:{s:11:"default_img";s:0:"";s:10:"custom_css";s:0:"";}', 'yes'),
(205, 'wpocup_plugin_version', '1.0', 'yes'),
(206, 'recently_activated', 'a:1:{s:52:"wpos-owl-carousel-ultimate/owl-carousel-ultimate.php";i:1547705509;}', 'yes'),
(223, 'category_children', 'a:0:{}', 'yes'),
(228, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(261, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1547798704;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=681 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(4, 7, '_edit_lock', '1547777553:1'),
(5, 7, '_wp_page_template', ''),
(6, 10, 'sa_slide1_content', ''),
(7, 10, 'sa_slide1_image_id', '17'),
(8, 10, 'sa_slide1_image_pos', 'center center'),
(9, 10, 'sa_slide1_image_size', 'cover'),
(10, 10, 'sa_slide1_image_repeat', 'no-repeat'),
(11, 10, 'sa_slide1_image_color', 'rgb(255, 255, 255)'),
(12, 10, 'sa_slide1_link_url', ''),
(13, 10, 'sa_slide1_link_target', '_self'),
(14, 10, 'sa_slide1_popup_type', 'NONE'),
(15, 10, 'sa_slide1_popup_imageid', ''),
(16, 10, 'sa_slide1_popup_imagetitle', ''),
(17, 10, 'sa_slide1_popup_video_id', ''),
(18, 10, 'sa_slide1_popup_video_type', ''),
(19, 10, 'sa_slide1_popup_background', 'no'),
(20, 10, 'sa_slide1_popup_html', ''),
(21, 10, 'sa_slide1_popup_shortcode', '0'),
(22, 10, 'sa_slide1_popup_bgcol', '#ffffff'),
(23, 10, 'sa_slide1_popup_width', '600'),
(24, 10, 'sa_slide2_content', ''),
(25, 10, 'sa_slide2_image_id', '16'),
(26, 10, 'sa_slide2_image_pos', 'center center'),
(27, 10, 'sa_slide2_image_size', 'cover'),
(28, 10, 'sa_slide2_image_repeat', 'no-repeat'),
(29, 10, 'sa_slide2_image_color', 'rgb(255, 255, 255)'),
(30, 10, 'sa_slide2_link_url', ''),
(31, 10, 'sa_slide2_link_target', '_self'),
(32, 10, 'sa_slide2_popup_type', 'NONE'),
(33, 10, 'sa_slide2_popup_imageid', ''),
(34, 10, 'sa_slide2_popup_imagetitle', ''),
(35, 10, 'sa_slide2_popup_video_id', ''),
(36, 10, 'sa_slide2_popup_video_type', ''),
(37, 10, 'sa_slide2_popup_background', 'no'),
(38, 10, 'sa_slide2_popup_html', ''),
(39, 10, 'sa_slide2_popup_shortcode', '0'),
(40, 10, 'sa_slide2_popup_bgcol', '#ffffff'),
(41, 10, 'sa_slide2_popup_width', '600'),
(42, 10, 'sa_slide3_content', ''),
(43, 10, 'sa_slide3_image_id', '15'),
(44, 10, 'sa_slide3_image_pos', 'center center'),
(45, 10, 'sa_slide3_image_size', 'cover'),
(46, 10, 'sa_slide3_image_repeat', 'no-repeat'),
(47, 10, 'sa_slide3_image_color', 'rgb(255, 255, 255)'),
(48, 10, 'sa_slide3_link_url', ''),
(49, 10, 'sa_slide3_link_target', '_self'),
(50, 10, 'sa_slide3_popup_type', 'NONE'),
(51, 10, 'sa_slide3_popup_imageid', ''),
(52, 10, 'sa_slide3_popup_imagetitle', ''),
(53, 10, 'sa_slide3_popup_video_id', ''),
(54, 10, 'sa_slide3_popup_video_type', ''),
(55, 10, 'sa_slide3_popup_background', 'no'),
(56, 10, 'sa_slide3_popup_html', ''),
(57, 10, 'sa_slide3_popup_shortcode', '0'),
(58, 10, 'sa_slide3_popup_bgcol', '#ffffff'),
(59, 10, 'sa_slide3_popup_width', '600'),
(60, 10, 'sa_slide4_content', ''),
(61, 10, 'sa_slide4_image_id', '14'),
(62, 10, 'sa_slide4_image_pos', 'center center'),
(63, 10, 'sa_slide4_image_size', 'cover'),
(64, 10, 'sa_slide4_image_repeat', 'no-repeat'),
(65, 10, 'sa_slide4_image_color', '#d0e0e3'),
(66, 10, 'sa_slide4_link_url', ''),
(67, 10, 'sa_slide4_link_target', '_self'),
(68, 10, 'sa_slide4_popup_type', 'NONE'),
(69, 10, 'sa_slide4_popup_imageid', ''),
(70, 10, 'sa_slide4_popup_imagetitle', ''),
(71, 10, 'sa_slide4_popup_video_id', ''),
(72, 10, 'sa_slide4_popup_video_type', ''),
(73, 10, 'sa_slide4_popup_background', 'no'),
(74, 10, 'sa_slide4_popup_html', ''),
(75, 10, 'sa_slide4_popup_shortcode', '0'),
(76, 10, 'sa_slide4_popup_bgcol', '#ffffff'),
(77, 10, 'sa_slide4_popup_width', '600'),
(78, 10, 'sa_slide5_content', ''),
(79, 10, 'sa_slide5_image_id', '13'),
(80, 10, 'sa_slide5_image_pos', 'center center'),
(81, 10, 'sa_slide5_image_size', 'cover'),
(82, 10, 'sa_slide5_image_repeat', 'no-repeat'),
(83, 10, 'sa_slide5_image_color', 'rgb(255, 255, 255)'),
(84, 10, 'sa_slide5_link_url', ''),
(85, 10, 'sa_slide5_link_target', '_self'),
(86, 10, 'sa_slide5_popup_type', 'NONE'),
(87, 10, 'sa_slide5_popup_imageid', ''),
(88, 10, 'sa_slide5_popup_imagetitle', ''),
(89, 10, 'sa_slide5_popup_video_id', ''),
(90, 10, 'sa_slide5_popup_video_type', ''),
(91, 10, 'sa_slide5_popup_background', 'no'),
(92, 10, 'sa_slide5_popup_html', ''),
(93, 10, 'sa_slide5_popup_shortcode', '0'),
(94, 10, 'sa_slide5_popup_bgcol', '#ffffff'),
(95, 10, 'sa_slide5_popup_width', '600'),
(96, 10, 'sa_slide6_content', ''),
(97, 10, 'sa_slide6_image_id', '12'),
(98, 10, 'sa_slide6_image_pos', 'center center'),
(99, 10, 'sa_slide6_image_size', 'cover'),
(100, 10, 'sa_slide6_image_repeat', 'no-repeat'),
(101, 10, 'sa_slide6_image_color', 'rgb(255, 255, 255)') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(102, 10, 'sa_slide6_link_url', ''),
(103, 10, 'sa_slide6_link_target', '_self'),
(104, 10, 'sa_slide6_popup_type', 'NONE'),
(105, 10, 'sa_slide6_popup_imageid', ''),
(106, 10, 'sa_slide6_popup_imagetitle', ''),
(107, 10, 'sa_slide6_popup_video_id', ''),
(108, 10, 'sa_slide6_popup_video_type', ''),
(109, 10, 'sa_slide6_popup_background', 'no'),
(110, 10, 'sa_slide6_popup_html', ''),
(111, 10, 'sa_slide6_popup_shortcode', '0'),
(112, 10, 'sa_slide6_popup_bgcol', '#ffffff'),
(113, 10, 'sa_slide6_popup_width', '600'),
(114, 10, 'sa_slide7_content', ''),
(115, 10, 'sa_slide7_image_id', '0'),
(116, 10, 'sa_slide7_image_pos', ''),
(117, 10, 'sa_slide7_image_size', ''),
(118, 10, 'sa_slide7_image_repeat', ''),
(119, 10, 'sa_slide7_image_color', ''),
(120, 10, 'sa_slide7_link_url', ''),
(121, 10, 'sa_slide7_link_target', ''),
(122, 10, 'sa_slide7_popup_type', 'NONE'),
(123, 10, 'sa_slide7_popup_imageid', ''),
(124, 10, 'sa_slide7_popup_imagetitle', ''),
(125, 10, 'sa_slide7_popup_video_id', ''),
(126, 10, 'sa_slide7_popup_video_type', ''),
(127, 10, 'sa_slide7_popup_background', 'no'),
(128, 10, 'sa_slide7_popup_html', ''),
(129, 10, 'sa_slide7_popup_shortcode', '0'),
(130, 10, 'sa_slide7_popup_bgcol', '#ffffff'),
(131, 10, 'sa_slide7_popup_width', '600'),
(132, 10, 'sa_slide8_content', '<div style="text-align: center; padding-bottom: 10px;">\r\n<div><img src="http://meiji.local:8080/wp-content/plugins/slide-anything/images/sample_logo8.png" alt="Logo 8" /></div>\r\n<h3>Company Name</h3>\r\n<p>Lorem ipsum dolor sit amet, cu usu cibo vituperata, id ius probo maiestatis inciderint, sit eu vide volutpat.</p>\r\n</div>'),
(133, 10, 'sa_slide8_image_id', '0'),
(134, 10, 'sa_slide8_image_pos', 'left top'),
(135, 10, 'sa_slide8_image_size', 'contain'),
(136, 10, 'sa_slide8_image_repeat', 'no-repeat'),
(137, 10, 'sa_slide8_image_color', '#ead1dc'),
(138, 10, 'sa_slide8_link_url', ''),
(139, 10, 'sa_slide8_link_target', '_self'),
(140, 10, 'sa_slide8_popup_type', 'NONE'),
(141, 10, 'sa_slide8_popup_imageid', ''),
(142, 10, 'sa_slide8_popup_imagetitle', ''),
(143, 10, 'sa_slide8_popup_video_id', ''),
(144, 10, 'sa_slide8_popup_video_type', ''),
(145, 10, 'sa_slide8_popup_background', 'no'),
(146, 10, 'sa_slide8_popup_html', ''),
(147, 10, 'sa_slide8_popup_shortcode', '0'),
(148, 10, 'sa_slide8_popup_bgcol', '#ffffff'),
(149, 10, 'sa_slide8_popup_width', '600'),
(150, 10, 'sa_disable_visual_editor', '0'),
(151, 10, 'sa_num_slides', '6'),
(152, 10, 'sa_slide_duration', '4'),
(153, 10, 'sa_slide_transition', '0.3'),
(154, 10, 'sa_slide_by', '1'),
(155, 10, 'sa_loop_slider', '1'),
(156, 10, 'sa_stop_hover', '1'),
(157, 10, 'sa_nav_arrows', '1'),
(158, 10, 'sa_pagination', '1'),
(159, 10, 'sa_shortcodes', '0'),
(160, 10, 'sa_random_order', '1'),
(161, 10, 'sa_reverse_order', '0'),
(162, 10, 'sa_mouse_drag', '0'),
(163, 10, 'sa_touch_drag', '1'),
(164, 10, 'sa_auto_height', '0'),
(165, 10, 'sa_items_width1', '1'),
(166, 10, 'sa_items_width2', '1'),
(167, 10, 'sa_items_width3', '1'),
(168, 10, 'sa_items_width4', '1'),
(169, 10, 'sa_items_width5', '1'),
(170, 10, 'sa_items_width6', '1'),
(171, 10, 'sa_transition', 'Fade'),
(172, 10, 'sa_css_id', 'sample_slider'),
(173, 10, 'sa_background_color', '#fafafa'),
(174, 10, 'sa_border_width', '1'),
(175, 10, 'sa_border_color', ''),
(176, 10, 'sa_border_radius', '5'),
(177, 10, 'sa_wrapper_padd_top', '0'),
(178, 10, 'sa_wrapper_padd_right', '0'),
(179, 10, 'sa_wrapper_padd_bottom', '0'),
(180, 10, 'sa_wrapper_padd_left', '0'),
(181, 10, 'sa_slide_min_height_perc', '50'),
(182, 10, 'sa_slide_padding_tb', '0'),
(183, 10, 'sa_slide_padding_lr', '0'),
(184, 10, 'sa_slide_margin_lr', '0'),
(185, 10, 'sa_autohide_arrows', '1'),
(186, 10, 'sa_slide_icons_location', 'Center Center'),
(187, 10, 'sa_slide_icons_visible', '0'),
(188, 10, 'sa_slide_icons_color', 'white selected'),
(189, 10, '_edit_lock', '1547780519:1'),
(190, 10, '_edit_last', '1'),
(191, 10, 'sa_slide1_char_count', '0'),
(192, 10, 'sa_slide2_char_count', '0'),
(193, 10, 'sa_slide3_char_count', '0'),
(194, 10, 'sa_slide4_char_count', '0'),
(195, 10, 'sa_slide5_char_count', '0'),
(196, 10, 'sa_slide6_char_count', '0'),
(197, 10, 'sa_slide7_char_count', '0'),
(198, 10, 'sa_slide8_char_count', '325'),
(199, 10, 'sa_info_added', '0'),
(200, 10, 'sa_info_deleted', '0'),
(201, 10, 'sa_duplicate_slide', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(202, 10, 'sa_info_duplicated', '0'),
(203, 10, 'sa_move_slide_up', '0'),
(204, 10, 'sa_info_moved', '0'),
(205, 10, 'sa_window_onload', '0'),
(206, 10, 'sa_strip_javascript', '0'),
(207, 10, 'sa_lazy_load_images', '0'),
(208, 12, '_wp_attached_file', '2019/01/img_mainimg_shoppc.jpg'),
(209, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:620;s:6:"height";i:300;s:4:"file";s:30:"2019/01/img_mainimg_shoppc.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"img_mainimg_shoppc-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"img_mainimg_shoppc-300x145.jpg";s:5:"width";i:300;s:6:"height";i:145;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(210, 13, '_wp_attached_file', '2019/01/img_mainimg02.png'),
(211, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:620;s:6:"height";i:300;s:4:"file";s:25:"2019/01/img_mainimg02.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"img_mainimg02-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"img_mainimg02-300x145.png";s:5:"width";i:300;s:6:"height";i:145;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(212, 14, '_wp_attached_file', '2019/01/img_mainimg_hohoemi.png'),
(213, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:620;s:6:"height";i:300;s:4:"file";s:31:"2019/01/img_mainimg_hohoemi.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"img_mainimg_hohoemi-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:31:"img_mainimg_hohoemi-300x145.png";s:5:"width";i:300;s:6:"height";i:145;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(214, 15, '_wp_attached_file', '2019/01/620_300_img_mainimg_onlypc2.jpg'),
(215, 15, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:620;s:6:"height";i:300;s:4:"file";s:39:"2019/01/620_300_img_mainimg_onlypc2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"620_300_img_mainimg_onlypc2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:39:"620_300_img_mainimg_onlypc2-300x145.jpg";s:5:"width";i:300;s:6:"height";i:145;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(216, 16, '_wp_attached_file', '2019/01/hohoemi_pc_top_mainpanel_B.jpg'),
(217, 16, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:620;s:6:"height";i:300;s:4:"file";s:38:"2019/01/hohoemi_pc_top_mainpanel_B.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:38:"hohoemi_pc_top_mainpanel_B-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:38:"hohoemi_pc_top_mainpanel_B-300x145.jpg";s:5:"width";i:300;s:6:"height";i:145;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(218, 17, '_wp_attached_file', '2019/01/img_mainimg01.png'),
(219, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:620;s:6:"height";i:300;s:4:"file";s:25:"2019/01/img_mainimg01.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"img_mainimg01-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"img_mainimg01-300x145.png";s:5:"width";i:300;s:6:"height";i:145;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(220, 18, '_menu_item_type', 'post_type'),
(221, 18, '_menu_item_menu_item_parent', '0'),
(222, 18, '_menu_item_object_id', '7'),
(223, 18, '_menu_item_object', 'page'),
(224, 18, '_menu_item_target', ''),
(225, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(226, 18, '_menu_item_xfn', ''),
(227, 18, '_menu_item_url', ''),
(228, 18, '_menu_item_orphaned', '1547715384'),
(229, 19, '_menu_item_type', 'post_type'),
(230, 19, '_menu_item_menu_item_parent', '0'),
(231, 19, '_menu_item_object_id', '7'),
(232, 19, '_menu_item_object', 'page'),
(233, 19, '_menu_item_target', ''),
(234, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(235, 19, '_menu_item_xfn', ''),
(236, 19, '_menu_item_url', ''),
(237, 19, '_menu_item_orphaned', '1547715384'),
(238, 20, '_menu_item_type', 'post_type'),
(239, 20, '_menu_item_menu_item_parent', '0'),
(240, 20, '_menu_item_object_id', '2'),
(241, 20, '_menu_item_object', 'page'),
(242, 20, '_menu_item_target', ''),
(243, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(244, 20, '_menu_item_xfn', ''),
(245, 20, '_menu_item_url', ''),
(246, 20, '_menu_item_orphaned', '1547715384'),
(247, 21, '_menu_item_type', 'post_type'),
(248, 21, '_menu_item_menu_item_parent', '0'),
(249, 21, '_menu_item_object_id', '7'),
(250, 21, '_menu_item_object', 'page'),
(251, 21, '_menu_item_target', ''),
(252, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(253, 21, '_menu_item_xfn', ''),
(254, 21, '_menu_item_url', ''),
(255, 21, '_menu_item_orphaned', '1547715403'),
(256, 22, '_menu_item_type', 'post_type'),
(257, 22, '_menu_item_menu_item_parent', '0'),
(258, 22, '_menu_item_object_id', '7'),
(259, 22, '_menu_item_object', 'page'),
(260, 22, '_menu_item_target', ''),
(261, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(262, 22, '_menu_item_xfn', ''),
(263, 22, '_menu_item_url', ''),
(264, 22, '_menu_item_orphaned', '1547715403'),
(265, 23, '_menu_item_type', 'post_type'),
(266, 23, '_menu_item_menu_item_parent', '0'),
(267, 23, '_menu_item_object_id', '2'),
(268, 23, '_menu_item_object', 'page'),
(269, 23, '_menu_item_target', ''),
(270, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(271, 23, '_menu_item_xfn', ''),
(272, 23, '_menu_item_url', ''),
(273, 23, '_menu_item_orphaned', '1547715403'),
(274, 24, '_menu_item_type', 'post_type'),
(275, 24, '_menu_item_menu_item_parent', '0'),
(276, 24, '_menu_item_object_id', '7'),
(277, 24, '_menu_item_object', 'page'),
(278, 24, '_menu_item_target', ''),
(279, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(280, 24, '_menu_item_xfn', ''),
(281, 24, '_menu_item_url', ''),
(282, 24, '_menu_item_orphaned', '1547715584'),
(283, 25, '_menu_item_type', 'post_type'),
(284, 25, '_menu_item_menu_item_parent', '0'),
(285, 25, '_menu_item_object_id', '7'),
(286, 25, '_menu_item_object', 'page'),
(287, 25, '_menu_item_target', ''),
(288, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(289, 25, '_menu_item_xfn', ''),
(290, 25, '_menu_item_url', ''),
(291, 25, '_menu_item_orphaned', '1547715584'),
(292, 26, '_menu_item_type', 'post_type'),
(293, 26, '_menu_item_menu_item_parent', '0'),
(294, 26, '_menu_item_object_id', '2'),
(295, 26, '_menu_item_object', 'page'),
(296, 26, '_menu_item_target', ''),
(297, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(298, 26, '_menu_item_xfn', ''),
(299, 26, '_menu_item_url', ''),
(300, 26, '_menu_item_orphaned', '1547715584'),
(301, 27, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(302, 27, '_menu_item_menu_item_parent', '0'),
(303, 27, '_menu_item_object_id', '7'),
(304, 27, '_menu_item_object', 'page'),
(305, 27, '_menu_item_target', ''),
(306, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(307, 27, '_menu_item_xfn', ''),
(308, 27, '_menu_item_url', ''),
(309, 27, '_menu_item_orphaned', '1547715617'),
(310, 28, '_menu_item_type', 'post_type'),
(311, 28, '_menu_item_menu_item_parent', '0'),
(312, 28, '_menu_item_object_id', '7'),
(313, 28, '_menu_item_object', 'page'),
(314, 28, '_menu_item_target', ''),
(315, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(316, 28, '_menu_item_xfn', ''),
(317, 28, '_menu_item_url', ''),
(318, 28, '_menu_item_orphaned', '1547715617'),
(319, 29, '_menu_item_type', 'post_type'),
(320, 29, '_menu_item_menu_item_parent', '0'),
(321, 29, '_menu_item_object_id', '2'),
(322, 29, '_menu_item_object', 'page'),
(323, 29, '_menu_item_target', ''),
(324, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(325, 29, '_menu_item_xfn', ''),
(326, 29, '_menu_item_url', ''),
(327, 29, '_menu_item_orphaned', '1547715617'),
(328, 30, '_menu_item_type', 'post_type'),
(329, 30, '_menu_item_menu_item_parent', '0'),
(330, 30, '_menu_item_object_id', '7'),
(331, 30, '_menu_item_object', 'page'),
(332, 30, '_menu_item_target', ''),
(333, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(334, 30, '_menu_item_xfn', ''),
(335, 30, '_menu_item_url', ''),
(336, 30, '_menu_item_orphaned', '1547715645'),
(337, 31, '_menu_item_type', 'post_type'),
(338, 31, '_menu_item_menu_item_parent', '0'),
(339, 31, '_menu_item_object_id', '7'),
(340, 31, '_menu_item_object', 'page'),
(341, 31, '_menu_item_target', ''),
(342, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(343, 31, '_menu_item_xfn', ''),
(344, 31, '_menu_item_url', ''),
(345, 31, '_menu_item_orphaned', '1547715645'),
(346, 32, '_menu_item_type', 'post_type'),
(347, 32, '_menu_item_menu_item_parent', '0'),
(348, 32, '_menu_item_object_id', '2'),
(349, 32, '_menu_item_object', 'page'),
(350, 32, '_menu_item_target', ''),
(351, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(352, 32, '_menu_item_xfn', ''),
(353, 32, '_menu_item_url', ''),
(354, 32, '_menu_item_orphaned', '1547715645'),
(355, 33, '_menu_item_type', 'taxonomy'),
(356, 33, '_menu_item_menu_item_parent', '38'),
(357, 33, '_menu_item_object_id', '5'),
(358, 33, '_menu_item_object', 'category'),
(359, 33, '_menu_item_target', ''),
(360, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(361, 33, '_menu_item_xfn', ''),
(362, 33, '_menu_item_url', ''),
(364, 34, '_menu_item_type', 'taxonomy'),
(365, 34, '_menu_item_menu_item_parent', '38'),
(366, 34, '_menu_item_object_id', '2'),
(367, 34, '_menu_item_object', 'category'),
(368, 34, '_menu_item_target', ''),
(369, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(370, 34, '_menu_item_xfn', ''),
(371, 34, '_menu_item_url', ''),
(373, 35, '_menu_item_type', 'taxonomy'),
(374, 35, '_menu_item_menu_item_parent', '38'),
(375, 35, '_menu_item_object_id', '3'),
(376, 35, '_menu_item_object', 'category'),
(377, 35, '_menu_item_target', ''),
(378, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(379, 35, '_menu_item_xfn', ''),
(380, 35, '_menu_item_url', ''),
(382, 36, '_menu_item_type', 'taxonomy'),
(383, 36, '_menu_item_menu_item_parent', '38'),
(384, 36, '_menu_item_object_id', '6'),
(385, 36, '_menu_item_object', 'category'),
(386, 36, '_menu_item_target', ''),
(387, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(388, 36, '_menu_item_xfn', ''),
(389, 36, '_menu_item_url', ''),
(391, 37, '_menu_item_type', 'taxonomy'),
(392, 37, '_menu_item_menu_item_parent', '38'),
(393, 37, '_menu_item_object_id', '4'),
(394, 37, '_menu_item_object', 'category'),
(395, 37, '_menu_item_target', ''),
(396, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(397, 37, '_menu_item_xfn', ''),
(398, 37, '_menu_item_url', ''),
(400, 38, '_menu_item_type', 'custom'),
(401, 38, '_menu_item_menu_item_parent', '0'),
(402, 38, '_menu_item_object_id', '38'),
(403, 38, '_menu_item_object', 'custom'),
(404, 38, '_menu_item_target', ''),
(405, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(406, 38, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(407, 38, '_menu_item_url', '#'),
(409, 39, '_menu_item_type', 'taxonomy'),
(410, 39, '_menu_item_menu_item_parent', '0'),
(411, 39, '_menu_item_object_id', '33'),
(412, 39, '_menu_item_object', 'post_tag'),
(413, 39, '_menu_item_target', ''),
(414, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(415, 39, '_menu_item_xfn', ''),
(416, 39, '_menu_item_url', ''),
(418, 40, '_menu_item_type', 'taxonomy'),
(419, 40, '_menu_item_menu_item_parent', '39'),
(420, 40, '_menu_item_object_id', '15'),
(421, 40, '_menu_item_object', 'post_tag'),
(422, 40, '_menu_item_target', ''),
(423, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(424, 40, '_menu_item_xfn', ''),
(425, 40, '_menu_item_url', ''),
(427, 41, '_menu_item_type', 'taxonomy'),
(428, 41, '_menu_item_menu_item_parent', '39'),
(429, 41, '_menu_item_object_id', '7'),
(430, 41, '_menu_item_object', 'post_tag'),
(431, 41, '_menu_item_target', ''),
(432, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(433, 41, '_menu_item_xfn', ''),
(434, 41, '_menu_item_url', ''),
(436, 42, '_menu_item_type', 'taxonomy'),
(437, 42, '_menu_item_menu_item_parent', '39'),
(438, 42, '_menu_item_object_id', '8'),
(439, 42, '_menu_item_object', 'post_tag'),
(440, 42, '_menu_item_target', ''),
(441, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(442, 42, '_menu_item_xfn', ''),
(443, 42, '_menu_item_url', ''),
(445, 43, '_menu_item_type', 'taxonomy'),
(446, 43, '_menu_item_menu_item_parent', '39'),
(447, 43, '_menu_item_object_id', '9'),
(448, 43, '_menu_item_object', 'post_tag'),
(449, 43, '_menu_item_target', ''),
(450, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(451, 43, '_menu_item_xfn', ''),
(452, 43, '_menu_item_url', ''),
(454, 44, '_menu_item_type', 'taxonomy'),
(455, 44, '_menu_item_menu_item_parent', '39'),
(456, 44, '_menu_item_object_id', '10'),
(457, 44, '_menu_item_object', 'post_tag'),
(458, 44, '_menu_item_target', ''),
(459, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(460, 44, '_menu_item_xfn', ''),
(461, 44, '_menu_item_url', ''),
(463, 45, '_menu_item_type', 'taxonomy'),
(464, 45, '_menu_item_menu_item_parent', '39'),
(465, 45, '_menu_item_object_id', '11'),
(466, 45, '_menu_item_object', 'post_tag'),
(467, 45, '_menu_item_target', ''),
(468, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(469, 45, '_menu_item_xfn', ''),
(470, 45, '_menu_item_url', ''),
(472, 46, '_menu_item_type', 'taxonomy'),
(473, 46, '_menu_item_menu_item_parent', '39'),
(474, 46, '_menu_item_object_id', '12'),
(475, 46, '_menu_item_object', 'post_tag'),
(476, 46, '_menu_item_target', ''),
(477, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(478, 46, '_menu_item_xfn', ''),
(479, 46, '_menu_item_url', ''),
(481, 47, '_menu_item_type', 'taxonomy'),
(482, 47, '_menu_item_menu_item_parent', '39'),
(483, 47, '_menu_item_object_id', '13'),
(484, 47, '_menu_item_object', 'post_tag'),
(485, 47, '_menu_item_target', ''),
(486, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(487, 47, '_menu_item_xfn', ''),
(488, 47, '_menu_item_url', ''),
(490, 48, '_menu_item_type', 'taxonomy'),
(491, 48, '_menu_item_menu_item_parent', '39'),
(492, 48, '_menu_item_object_id', '14'),
(493, 48, '_menu_item_object', 'post_tag'),
(494, 48, '_menu_item_target', ''),
(495, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(496, 48, '_menu_item_xfn', ''),
(497, 48, '_menu_item_url', ''),
(499, 49, '_menu_item_type', 'taxonomy'),
(500, 49, '_menu_item_menu_item_parent', '0'),
(501, 49, '_menu_item_object_id', '34'),
(502, 49, '_menu_item_object', 'post_tag'),
(503, 49, '_menu_item_target', ''),
(504, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(505, 49, '_menu_item_xfn', ''),
(506, 49, '_menu_item_url', ''),
(508, 50, '_menu_item_type', 'taxonomy'),
(509, 50, '_menu_item_menu_item_parent', '49'),
(510, 50, '_menu_item_object_id', '16'),
(511, 50, '_menu_item_object', 'post_tag'),
(512, 50, '_menu_item_target', ''),
(513, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(514, 50, '_menu_item_xfn', ''),
(515, 50, '_menu_item_url', ''),
(517, 51, '_menu_item_type', 'taxonomy'),
(518, 51, '_menu_item_menu_item_parent', '49'),
(519, 51, '_menu_item_object_id', '17') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(520, 51, '_menu_item_object', 'post_tag'),
(521, 51, '_menu_item_target', ''),
(522, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(523, 51, '_menu_item_xfn', ''),
(524, 51, '_menu_item_url', ''),
(526, 52, '_menu_item_type', 'taxonomy'),
(527, 52, '_menu_item_menu_item_parent', '49'),
(528, 52, '_menu_item_object_id', '26'),
(529, 52, '_menu_item_object', 'post_tag'),
(530, 52, '_menu_item_target', ''),
(531, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(532, 52, '_menu_item_xfn', ''),
(533, 52, '_menu_item_url', ''),
(535, 53, '_menu_item_type', 'taxonomy'),
(536, 53, '_menu_item_menu_item_parent', '49'),
(537, 53, '_menu_item_object_id', '27'),
(538, 53, '_menu_item_object', 'post_tag'),
(539, 53, '_menu_item_target', ''),
(540, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(541, 53, '_menu_item_xfn', ''),
(542, 53, '_menu_item_url', ''),
(544, 54, '_menu_item_type', 'taxonomy'),
(545, 54, '_menu_item_menu_item_parent', '49'),
(546, 54, '_menu_item_object_id', '18'),
(547, 54, '_menu_item_object', 'post_tag'),
(548, 54, '_menu_item_target', ''),
(549, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(550, 54, '_menu_item_xfn', ''),
(551, 54, '_menu_item_url', ''),
(553, 55, '_menu_item_type', 'taxonomy'),
(554, 55, '_menu_item_menu_item_parent', '49'),
(555, 55, '_menu_item_object_id', '19'),
(556, 55, '_menu_item_object', 'post_tag'),
(557, 55, '_menu_item_target', ''),
(558, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(559, 55, '_menu_item_xfn', ''),
(560, 55, '_menu_item_url', ''),
(562, 56, '_menu_item_type', 'taxonomy'),
(563, 56, '_menu_item_menu_item_parent', '49'),
(564, 56, '_menu_item_object_id', '20'),
(565, 56, '_menu_item_object', 'post_tag'),
(566, 56, '_menu_item_target', ''),
(567, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(568, 56, '_menu_item_xfn', ''),
(569, 56, '_menu_item_url', ''),
(571, 57, '_menu_item_type', 'taxonomy'),
(572, 57, '_menu_item_menu_item_parent', '49'),
(573, 57, '_menu_item_object_id', '21'),
(574, 57, '_menu_item_object', 'post_tag'),
(575, 57, '_menu_item_target', ''),
(576, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(577, 57, '_menu_item_xfn', ''),
(578, 57, '_menu_item_url', ''),
(580, 58, '_menu_item_type', 'taxonomy'),
(581, 58, '_menu_item_menu_item_parent', '49'),
(582, 58, '_menu_item_object_id', '22'),
(583, 58, '_menu_item_object', 'post_tag'),
(584, 58, '_menu_item_target', ''),
(585, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(586, 58, '_menu_item_xfn', ''),
(587, 58, '_menu_item_url', ''),
(589, 59, '_menu_item_type', 'taxonomy'),
(590, 59, '_menu_item_menu_item_parent', '49'),
(591, 59, '_menu_item_object_id', '23'),
(592, 59, '_menu_item_object', 'post_tag'),
(593, 59, '_menu_item_target', ''),
(594, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(595, 59, '_menu_item_xfn', ''),
(596, 59, '_menu_item_url', ''),
(598, 60, '_menu_item_type', 'taxonomy'),
(599, 60, '_menu_item_menu_item_parent', '49'),
(600, 60, '_menu_item_object_id', '24'),
(601, 60, '_menu_item_object', 'post_tag'),
(602, 60, '_menu_item_target', ''),
(603, 60, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(604, 60, '_menu_item_xfn', ''),
(605, 60, '_menu_item_url', ''),
(607, 61, '_menu_item_type', 'taxonomy'),
(608, 61, '_menu_item_menu_item_parent', '49'),
(609, 61, '_menu_item_object_id', '25'),
(610, 61, '_menu_item_object', 'post_tag'),
(611, 61, '_menu_item_target', ''),
(612, 61, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(613, 61, '_menu_item_xfn', ''),
(614, 61, '_menu_item_url', ''),
(616, 62, '_menu_item_type', 'taxonomy'),
(617, 62, '_menu_item_menu_item_parent', '0'),
(618, 62, '_menu_item_object_id', '35'),
(619, 62, '_menu_item_object', 'post_tag'),
(620, 62, '_menu_item_target', ''),
(621, 62, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(622, 62, '_menu_item_xfn', ''),
(623, 62, '_menu_item_url', ''),
(625, 63, '_menu_item_type', 'taxonomy'),
(626, 63, '_menu_item_menu_item_parent', '62'),
(627, 63, '_menu_item_object_id', '28'),
(628, 63, '_menu_item_object', 'post_tag'),
(629, 63, '_menu_item_target', ''),
(630, 63, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(631, 63, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(632, 63, '_menu_item_url', ''),
(634, 64, '_menu_item_type', 'taxonomy'),
(635, 64, '_menu_item_menu_item_parent', '62'),
(636, 64, '_menu_item_object_id', '29'),
(637, 64, '_menu_item_object', 'post_tag'),
(638, 64, '_menu_item_target', ''),
(639, 64, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(640, 64, '_menu_item_xfn', ''),
(641, 64, '_menu_item_url', ''),
(643, 65, '_menu_item_type', 'taxonomy'),
(644, 65, '_menu_item_menu_item_parent', '62'),
(645, 65, '_menu_item_object_id', '30'),
(646, 65, '_menu_item_object', 'post_tag'),
(647, 65, '_menu_item_target', ''),
(648, 65, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(649, 65, '_menu_item_xfn', ''),
(650, 65, '_menu_item_url', ''),
(652, 66, '_menu_item_type', 'taxonomy'),
(653, 66, '_menu_item_menu_item_parent', '62'),
(654, 66, '_menu_item_object_id', '31'),
(655, 66, '_menu_item_object', 'post_tag'),
(656, 66, '_menu_item_target', ''),
(657, 66, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(658, 66, '_menu_item_xfn', ''),
(659, 66, '_menu_item_url', ''),
(661, 67, '_menu_item_type', 'custom'),
(662, 67, '_menu_item_menu_item_parent', '0'),
(663, 67, '_menu_item_object_id', '67'),
(664, 67, '_menu_item_object', 'custom'),
(665, 67, '_menu_item_target', ''),
(666, 67, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(667, 67, '_menu_item_xfn', ''),
(668, 67, '_menu_item_url', '#'),
(670, 68, '_menu_item_type', 'taxonomy'),
(671, 68, '_menu_item_menu_item_parent', '0'),
(672, 68, '_menu_item_object_id', '32'),
(673, 68, '_menu_item_object', 'category'),
(674, 68, '_menu_item_target', ''),
(675, 68, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(676, 68, '_menu_item_xfn', ''),
(677, 68, '_menu_item_url', '') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-01-08 06:31:30', '2019-01-08 06:31:30', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2019-01-08 06:31:30', '2019-01-08 06:31:30', '', 0, 'http://meiji.local:8080/?p=1', 0, 'post', '', 1),
(2, 1, '2019-01-08 06:31:30', '2019-01-08 06:31:30', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://meiji.local:8080/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2019-01-08 06:31:30', '2019-01-08 06:31:30', '', 0, 'http://meiji.local:8080/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-01-08 06:31:30', '2019-01-08 06:31:30', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://meiji.local:8080.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2019-01-08 06:31:30', '2019-01-08 06:31:30', '', 0, 'http://meiji.local:8080/?page_id=3', 0, 'page', '', 0),
(6, 1, '2019-01-16 10:22:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-01-16 10:22:14', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=6', 0, 'post', '', 0),
(7, 1, '2019-01-16 10:23:23', '2019-01-16 10:23:23', '<!-- wp:paragraph -->\n<p>\n\n[slide-anything id="10"]\n\n</p>\n<!-- /wp:paragraph -->', 'landing-page', '', 'publish', 'closed', 'closed', '', 'landing-page', '', '', '2019-01-17 06:28:42', '2019-01-17 06:28:42', '', 0, 'http://meiji.local:8080/?page_id=7', 0, 'page', '', 0),
(8, 1, '2019-01-16 10:23:23', '2019-01-16 10:23:23', '', 'landing-page', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2019-01-16 10:23:23', '2019-01-16 10:23:23', '', 7, 'http://meiji.local:8080/2019/01/16/7-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2019-01-17 06:10:24', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-17 06:10:24', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?post_type=wpocup_slider&p=9', 0, 'wpocup_slider', '', 0),
(10, 1, '2019-01-17 06:11:40', '2019-01-17 06:11:40', '', 'Sample Slider', '', 'publish', 'closed', 'closed', '', 'sample-slider', '', '', '2019-01-17 08:37:30', '2019-01-17 08:37:30', '', 0, 'http://meiji.local:8080/2019/01/17/sample-slider/', 0, 'sa_slider', '', 0),
(11, 1, '2019-01-17 06:28:42', '2019-01-17 06:28:42', '<!-- wp:paragraph -->\n<p>\n\n[slide-anything id="10"]\n\n</p>\n<!-- /wp:paragraph -->', 'landing-page', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2019-01-17 06:28:42', '2019-01-17 06:28:42', '', 7, 'http://meiji.local:8080/2019/01/17/7-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2019-01-17 06:40:30', '2019-01-17 06:40:30', '', 'img_mainimg_shoppc', '', 'inherit', 'open', 'closed', '', 'img_mainimg_shoppc', '', '', '2019-01-17 06:40:30', '2019-01-17 06:40:30', '', 10, 'http://meiji.local:8080/wp-content/uploads/2019/01/img_mainimg_shoppc.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 1, '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 'img_mainimg02', '', 'inherit', 'open', 'closed', '', 'img_mainimg02', '', '', '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 10, 'http://meiji.local:8080/wp-content/uploads/2019/01/img_mainimg02.png', 0, 'attachment', 'image/png', 0),
(14, 1, '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 'img_mainimg_hohoemi', '', 'inherit', 'open', 'closed', '', 'img_mainimg_hohoemi', '', '', '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 10, 'http://meiji.local:8080/wp-content/uploads/2019/01/img_mainimg_hohoemi.png', 0, 'attachment', 'image/png', 0),
(15, 1, '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', '620_300_img_mainimg_onlypc2', '', 'inherit', 'open', 'closed', '', '620_300_img_mainimg_onlypc2', '', '', '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 10, 'http://meiji.local:8080/wp-content/uploads/2019/01/620_300_img_mainimg_onlypc2.jpg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 'hohoemi_pc_top_mainpanel_B', '', 'inherit', 'open', 'closed', '', 'hohoemi_pc_top_mainpanel_b', '', '', '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 10, 'http://meiji.local:8080/wp-content/uploads/2019/01/hohoemi_pc_top_mainpanel_B.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 'img_mainimg01', '', 'inherit', 'open', 'closed', '', 'img_mainimg01', '', '', '2019-01-17 06:40:31', '2019-01-17 06:40:31', '', 10, 'http://meiji.local:8080/wp-content/uploads/2019/01/img_mainimg01.png', 0, 'attachment', 'image/png', 0),
(18, 1, '2019-01-17 08:56:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:56:24', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=18', 1, 'nav_menu_item', '', 0),
(19, 1, '2019-01-17 08:56:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:56:24', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=19', 1, 'nav_menu_item', '', 0),
(20, 1, '2019-01-17 08:56:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:56:24', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=20', 1, 'nav_menu_item', '', 0),
(21, 1, '2019-01-17 08:56:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:56:43', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=21', 1, 'nav_menu_item', '', 0),
(22, 1, '2019-01-17 08:56:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:56:43', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=22', 1, 'nav_menu_item', '', 0),
(23, 1, '2019-01-17 08:56:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:56:43', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=23', 1, 'nav_menu_item', '', 0),
(24, 1, '2019-01-17 08:59:44', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:59:44', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=24', 1, 'nav_menu_item', '', 0),
(25, 1, '2019-01-17 08:59:44', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:59:44', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=25', 1, 'nav_menu_item', '', 0),
(26, 1, '2019-01-17 08:59:44', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 08:59:44', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=26', 1, 'nav_menu_item', '', 0),
(27, 1, '2019-01-17 09:00:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 09:00:17', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=27', 1, 'nav_menu_item', '', 0),
(28, 1, '2019-01-17 09:00:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 09:00:17', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2019-01-17 09:00:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 09:00:17', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2019-01-17 09:00:45', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 09:00:45', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=30', 1, 'nav_menu_item', '', 0),
(31, 1, '2019-01-17 09:00:45', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 09:00:45', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2019-01-17 09:00:45', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-17 09:00:45', '0000-00-00 00:00:00', '', 0, 'http://meiji.local:8080/?p=32', 1, 'nav_menu_item', '', 0),
(33, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '33', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=33', 5, 'nav_menu_item', '', 0),
(34, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '34', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=34', 2, 'nav_menu_item', '', 0),
(35, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=35', 3, 'nav_menu_item', '', 0),
(36, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=36', 6, 'nav_menu_item', '', 0),
(37, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=37', 4, 'nav_menu_item', '', 0),
(38, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 'Categories', '', 'publish', 'closed', 'closed', '', 'categories', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=39', 7, 'nav_menu_item', '', 0),
(40, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=40', 16, 'nav_menu_item', '', 0),
(41, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=41', 8, 'nav_menu_item', '', 0),
(42, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=42', 9, 'nav_menu_item', '', 0),
(43, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '43', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=43', 10, 'nav_menu_item', '', 0),
(44, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '44', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=44', 11, 'nav_menu_item', '', 0),
(45, 1, '2019-01-17 09:06:25', '2019-01-17 09:06:25', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2019-01-17 09:06:25', '2019-01-17 09:06:25', '', 0, 'http://meiji.local:8080/?p=45', 12, 'nav_menu_item', '', 0),
(46, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=46', 13, 'nav_menu_item', '', 0),
(47, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '47', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=47', 14, 'nav_menu_item', '', 0),
(48, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '48', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=48', 15, 'nav_menu_item', '', 0),
(49, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=49', 17, 'nav_menu_item', '', 0),
(50, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=50', 18, 'nav_menu_item', '', 0),
(51, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=51', 19, 'nav_menu_item', '', 0),
(52, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=52', 28, 'nav_menu_item', '', 0),
(53, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=53', 29, 'nav_menu_item', '', 0),
(54, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '54', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=54', 20, 'nav_menu_item', '', 0),
(55, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '55', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=55', 21, 'nav_menu_item', '', 0),
(56, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=56', 22, 'nav_menu_item', '', 0),
(57, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '57', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=57', 23, 'nav_menu_item', '', 0),
(58, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '58', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=58', 24, 'nav_menu_item', '', 0),
(59, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '59', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=59', 25, 'nav_menu_item', '', 0),
(60, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '60', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=60', 26, 'nav_menu_item', '', 0),
(61, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '61', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=61', 27, 'nav_menu_item', '', 0),
(62, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '62', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=62', 30, 'nav_menu_item', '', 0),
(63, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '63', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=63', 31, 'nav_menu_item', '', 0),
(64, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '64', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=64', 32, 'nav_menu_item', '', 0),
(65, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '65', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=65', 33, 'nav_menu_item', '', 0),
(66, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '66', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=66', 34, 'nav_menu_item', '', 0),
(67, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 'hatsupapa', '', 'publish', 'closed', 'closed', '', 'hatsupapa', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=67', 35, 'nav_menu_item', '', 0),
(68, 1, '2019-01-17 09:06:26', '2019-01-17 09:06:26', ' ', '', '', 'publish', 'closed', 'closed', '', '68', '', '', '2019-01-17 09:06:26', '2019-01-17 09:06:26', '', 0, 'http://meiji.local:8080/?p=68', 36, 'nav_menu_item', '', 0),
(69, 1, '2019-01-18 02:14:56', '2019-01-18 02:14:56', '<!-- wp:paragraph -->\n<p> [slide-anything id="10"] </p>\n<!-- /wp:paragraph -->', 'landing-page', '', 'inherit', 'closed', 'closed', '', '7-autosave-v1', '', '', '2019-01-18 02:14:56', '2019-01-18 02:14:56', '', 7, 'http://meiji.local:8080/2019/01/18/7-autosave-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(33, 36, 0),
(34, 36, 0),
(35, 36, 0),
(36, 36, 0),
(37, 36, 0),
(38, 36, 0),
(39, 36, 0),
(40, 36, 0),
(41, 36, 0),
(42, 36, 0),
(43, 36, 0),
(44, 36, 0),
(45, 36, 0),
(46, 36, 0),
(47, 36, 0),
(48, 36, 0),
(49, 36, 0),
(50, 36, 0),
(51, 36, 0),
(52, 36, 0),
(53, 36, 0),
(54, 36, 0),
(55, 36, 0),
(56, 36, 0),
(57, 36, 0),
(58, 36, 0),
(59, 36, 0),
(60, 36, 0),
(61, 36, 0),
(62, 36, 0),
(63, 36, 0),
(64, 36, 0),
(65, 36, 0),
(66, 36, 0),
(67, 36, 0),
(68, 36, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'category', '', 0, 0),
(3, 3, 'category', '', 0, 0),
(4, 4, 'category', '', 0, 0),
(5, 5, 'category', '', 0, 0),
(6, 6, 'category', '', 0, 0),
(7, 7, 'post_tag', '', 0, 0),
(8, 8, 'post_tag', '', 0, 0),
(9, 9, 'post_tag', '', 0, 0),
(10, 10, 'post_tag', '', 0, 0),
(11, 11, 'post_tag', '', 0, 0),
(12, 12, 'post_tag', '', 0, 0),
(13, 13, 'post_tag', '', 0, 0),
(14, 14, 'post_tag', '', 0, 0),
(15, 15, 'post_tag', '', 0, 0),
(16, 16, 'post_tag', '', 0, 0),
(17, 17, 'post_tag', '', 0, 0),
(18, 18, 'post_tag', '', 0, 0),
(19, 19, 'post_tag', '', 0, 0),
(20, 20, 'post_tag', '', 0, 0),
(21, 21, 'post_tag', '', 0, 0),
(22, 22, 'post_tag', '', 0, 0),
(23, 23, 'post_tag', '', 0, 0),
(24, 24, 'post_tag', '', 0, 0),
(25, 25, 'post_tag', '', 0, 0),
(26, 26, 'post_tag', '', 0, 0),
(27, 27, 'post_tag', '', 0, 0),
(28, 28, 'post_tag', '', 0, 0),
(29, 29, 'post_tag', '', 0, 0),
(30, 30, 'post_tag', '', 0, 0),
(31, 31, 'post_tag', '', 0, 0),
(32, 32, 'category', '', 0, 0),
(33, 33, 'post_tag', '', 0, 0),
(34, 34, 'post_tag', '', 0, 0),
(35, 35, 'post_tag', '', 0, 0),
(36, 36, 'nav_menu', '', 0, 36),
(37, 37, 'post_tag', '', 0, 0),
(38, 38, 'post_tag', '', 0, 0),
(39, 39, 'post_tag', '', 0, 0),
(40, 40, 'post_tag', '', 0, 0),
(41, 41, 'post_tag', '', 0, 0),
(42, 42, 'post_tag', '', 0, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'deals', 'deals', 0),
(3, 'eat', 'eat', 0),
(4, 'study', 'study', 0),
(5, 'ask', 'ask', 0),
(6, 'play', 'play', 0),
(7, '2 months', 'pregnancy_m2', 0),
(8, '3 months', 'pregnancy_m3', 0),
(9, '4 months', 'pregnancy_m4', 0),
(10, 'pregnancy_m5', 'pregnancy_m5', 0),
(11, 'pregnancy_m6', 'pregnancy_m6', 0),
(12, 'pregnancy_m7', 'pregnancy_m7', 0),
(13, 'pregnancy_m8', 'pregnancy_m8', 0),
(14, 'pregnancy_m9', 'pregnancy_m9', 0),
(15, 'pregnancy_m10', 'pregnancy_m10', 0),
(16, '0 month', 'm0', 0),
(17, '1 month', 'm1', 0),
(18, '2 months', 'm2', 0),
(19, '3 months', 'm3', 0),
(20, 'm4', 'm4', 0),
(21, 'm5', 'm5', 0),
(22, 'm6', 'm6', 0),
(23, 'm7', 'm7', 0),
(24, 'm8', 'm8', 0),
(25, 'm9', 'm9', 0),
(26, 'm10', 'm10', 0),
(27, 'm11', 'm11', 0),
(28, 'age_1', 'age_1', 0),
(29, '1 to 1 half year old', 'age_1-5', 0),
(30, 'age_2', 'age_2', 0),
(31, 'age_3', 'age_3', 0),
(32, 'products', 'products', 0),
(33, 'premama', 'premama', 0),
(34, 'mama', 'mama', 0),
(35, 'age', 'age', 0),
(36, 'main-menu', 'main-menu', 0),
(37, 'Early Pregnancy', 'premama1', 0),
(38, 'Mid Pregnancy', 'premama2', 0),
(39, 'premama3', 'premama3', 0),
(40, '0 month to 3 months after birth', 'mama1', 0),
(41, 'mama2', 'mama2', 0),
(42, 'mama3', 'mama3', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:3:{s:64:"a85765da888457474c8f092631273e942c9a7b87709f4d797b61c4336cdfe39b";a:4:{s:10:"expiration";i:1547806932;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36";s:5:"login";i:1547634132;}s:64:"de0620982ec0f7c4b802765eac9467e8ca7f181a45b76f416ad90d9feb9d1aa4";a:4:{s:10:"expiration";i:1547964668;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36";s:5:"login";i:1547791868;}s:64:"1e02a170b95311c3a8eb0b5db41265be49119878c662bcb2450926d83bb20764";a:4:{s:10:"expiration";i:1547970884;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36";s:5:"login";i:1547798084;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '6'),
(18, 1, 'closedpostboxes_sa_slider', 'a:0:{}'),
(19, 1, 'metaboxhidden_sa_slider', 'a:1:{i:0;s:7:"slugdiv";}'),
(20, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse&widgets_access=off'),
(21, 1, 'wp_user-settings-time', '1547792322'),
(22, 1, 'sa_ignore_notice', 'true'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:0:{}'),
(25, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(26, 1, 'nav_menu_recently_edited', '36') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BOkEWZ8XPFPGmLBJJvqOI3LO9nTP3S0', 'admin', 'blackant150@yahoo.com', '', '2019-01-08 06:31:29', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

